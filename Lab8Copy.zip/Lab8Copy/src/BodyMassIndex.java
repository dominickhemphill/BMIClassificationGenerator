import java.util.Scanner;

/**
 * @author Dom Hemphill
 * @version 1.0
 * Class: CSCI-2467
 * Date: 04/05/2020
 * Instructor: Barry Mesa
 * Calculates the BMI of user and displays BMI classification
 */

public class BodyMassIndex {

    // import scanner to accept user input
    private static Scanner input = new Scanner(System.in);

    // input error message
    private static final String INPUT_ERROR = "Input is not valid, try again";

    public static void main(String[] args) {
        // variables used to store user weight and height
        double lbs;
        double inches;
        double meters = 0;
        double kgs = 0;
        double bmi = 0;
        String Classification = null;


        // grab weight from user
        System.out.println("Calulate BMI");
        do {
            System.out.println("Enter weight (lbs)");
            String firstInput = input.next();
            lbs = inputWeight(firstInput);
        } while (lbs <= 0);

        // grab height from user
        do {
            System.out.println("Enter height (inches)");
            String secondInput = input.next();
            inches = inputHeight(secondInput);
        } while (inches <= 0);

        // work our magic and return results
        System.out.println("Your BMI is " + calcBMI(lbs, inches));
        // return classification based on black magic worked
        System.out.println("Your BMI classifiaton is " + bmiClassification(calcBMI(lbs, inches)));
    }

    private static double inputWeight(String firstInput) {
        double convertedInputOne = 0;
        try {
            convertedInputOne = Double.parseDouble(firstInput);
            if (convertedInputOne <= 0) {
                System.out.println(INPUT_ERROR);
            }
        } catch (NumberFormatException ex) {
            System.out.println(INPUT_ERROR);
        }
        return convertedInputOne;
    }

    private static double inputHeight(String secondInput) {
        double convertedInputTwo = 0;
        try {
            convertedInputTwo = Double.parseDouble(secondInput);
            if (convertedInputTwo <= 0) {
                System.out.println(INPUT_ERROR);
            }
        } catch (NumberFormatException ex) {
            System.out.println(INPUT_ERROR);
        }
        return convertedInputTwo;
    }

    // method that calculates BMI using convertToKilograms() and convertToMeters() methods
    public static double calcBMI(double lbs, double inches) {
        double bmi = convertToKilograms(lbs) / (convertToMeters(inches) * convertToMeters(inches));
        return bmi;
    }

    // method used to convert user weight from pounds to kilograms #1st input from user
    public static double convertToKilograms(double lbs) {
        double kilograms = lbs / 2.2046;
        return kilograms;
    }

    // method used to convert user weight from inches to meters #2nd input from user
    public static double convertToMeters(double inches) {
        double meters = inches / 39.37;
        return meters;
    }

    // method used after calculation to return a user classification based on the results
    public static String bmiClassification(double bmi) {
        if (bmi >= 30.0) {
            return "Obese";
        } else if (bmi <= 29.99 && bmi >= 25.0) {
            return "Overweight";
        } else if (bmi <= 24.99 && bmi >= 18.5) {
            return "Normal";
        } else if (bmi <= 18.4) {
            return "Underweight";
        } else {
            return "incorrect input";
        }
    }

}
